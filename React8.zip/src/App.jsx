import { BrowserRouter, Route, Routes } from 'react-router-dom'
import './App.css'
import Routerer from './routes/Routerer'

function App() {

  return (
    <>
     <Routerer/>
    </>
  )
}

export default App
